from virusCode.server import server

server.launch()
