MoneyModel example modified to:

1) customize the amount of data to be collected
-> in the present case, only simulation state at even simulation steps is recorded

2) report datacollector objects with batchrunner